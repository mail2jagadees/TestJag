package com.java.laoprograms;

public class Staticprogram {

	public static void main(String[] args) {
		// Local variable
		
		int x = (int) 20.00; // type cast manually, narrowing
		double y = x;//type cast automatically, widening
		System.out.println(x);
		System.out.println(y);	

	}

	
	
}



