package com.java.laoprograms;

import java.io.StringBufferInputStream;

public class ReverseString {

	public static void main(String[] args) {
		
//method 1
		
		///String a = "jagadeeswarandraksha & ahskardnarawseedagaj";
		
		//use a method string buffer
		//StringBuffer buffer= new StringBuffer();
		//buffer.append(a);
		//StringBuffer reverse= buffer.reverse();
		//System.out.println(reverse);

		
//method 2		
		 String given = "raksha";
		       String reverse ="";
		      char[] chararray = given.toCharArray();
		         
		         for (int i = chararray.length-1;i>=0;i--) {
		            
		            reverse=reverse+chararray[i];
		        }
		         
		         System.out.println(reverse);
		
	}

}
