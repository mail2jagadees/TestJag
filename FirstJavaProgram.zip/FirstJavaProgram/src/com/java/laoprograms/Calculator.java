package com.java.laoprograms;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class Calculator {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<>();
	      list.add("A");
	      list.add("B");
	      list.add("C");
	      list.add("D");
	      List<String> list1 = new LinkedList<>();
	      list1.add("A");
	      list1.add("B");
	      list1.add("C");
	      list1.add("D");
	      System.out.println(list);
	      System.out.println(list1);
}}
