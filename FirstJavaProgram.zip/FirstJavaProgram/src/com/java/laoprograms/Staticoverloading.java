package com.java.laoprograms;

public class Staticoverloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// static method overloading
		System.out.println("This is overloading");
		
		addition1 object= new addition1();
		//object.add(12, 23);// check this comment
		addition1.add(22, 33);
	
	}
}

class addition1 {

	public static void add(int a, int b)
	{
		int c= a+b;
		System.out.println(c);
		}
	public void add(int a, int b,int c)
	{
		int d= a+b+c;
		System.out.println(d);
		}
	public void add1(int c, int d)
	{
		int e= c+d;
		System.out.println(e);
		}
	
	

	}

