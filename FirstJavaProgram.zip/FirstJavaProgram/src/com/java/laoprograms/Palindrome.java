package com.java.laoprograms;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// first lets reverse a number
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number: ");
		int number=sc.nextInt();
		
		//reverse  
		
		int reverse = 0;
		
		while(number!=0)
		{
			reverse=reverse*10 + number%10; // 3+ 5
			number=number/10; // 153/10= 15
		}
	 
		System.out.println("reverse number is: " + reverse);
		
	
	}

}
