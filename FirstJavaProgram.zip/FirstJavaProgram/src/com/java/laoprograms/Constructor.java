package com.java.laoprograms;

public class Constructor {

	public static void main(String[] args) {
		// constructor
		System.out.println("This is starting inside main");
		two O2=new two();
		O2.three();
		
}
}

class two 
{
	two(){
		System.out.println("This is constructor");
	}
	
	void three()
	{
		System.out.println("This is usual method");	
	}
}

//Constuctor name is same as class name " two"
//when we create object itself it will be called as we dont need to call
//constructor don't have any return type
