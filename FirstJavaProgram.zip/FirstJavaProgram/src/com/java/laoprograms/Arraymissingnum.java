package com.java.laoprograms;

public class Arraymissingnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= { 1,2,3,4,6};
		int sum1 = 0;
		int sum2= 0;
		int missing;
		
		//find missing number
		// total of array 16
		// total of range 1,2,3,4,5,6- 21
		// missing= sum2-sum1
		
		for (int i = 0; i < a.length; i++) {
			
			sum1=sum1+a[i];
			}
		   System.out.println("sum1 " + sum1 );
		
		for (int i = 1; i <=6; i++) {
			 
			sum2=sum2+i;
		}
	
		System.out.println("sum2 " + sum2 );
		
		missing = sum2-sum1;
		
		System.out.println("missing number is " + missing );
		
		}
		
	    
 

}
