package com.java.laoprograms;

public class Occurancestring {

	public static void main(String[] args) {
		// occurance of a string
		// string= "jagadeeswaran" find number of e is in a program
		
		//Method-1 using iteration
		
		String given = "jagadeeswaranraksha" ;
		char find = 'a';
		int occur = 0;
		
		for (int i = 0; i < given.length(); i++) {
			
			if (given.charAt(i)==find) {
				
				occur=occur+1;
			}
			
			
		}
		
		
		System.out.println(occur);
		
		
	}}
