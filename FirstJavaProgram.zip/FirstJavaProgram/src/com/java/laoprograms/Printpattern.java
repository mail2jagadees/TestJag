package com.java.laoprograms;

import java.util.Iterator;

public class Printpattern {

	public static void main(String[] args) {
		// Print below star pattern: This is one of the best programs to learn loop
		// *
		// **
		// ***
		// ****
		for(int i=1; i<5; i++)   
		{   
		for(int j=1; j<=i; j++)   
		{   
		System.out.print(j);   
		}   
		System.out.println();   
		
		}}}
		
