package com.java.laoprograms;

public class Arraysum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int sum = 0;
		
		int a[]={12,22,33,44,55};
		
		for (int i = 0; i < a.length; i++) {
			
			sum=sum+a[i];
		
		
			
		}
		

		System.out.println("the sum is " + sum);
}}

