package com.java.laoprograms;

public class Methodoverloading {

	public static void main(String[] args) {
		// method overloading
		System.out.println("This is overloading");
		
		addition object= new addition();
		object.add(12, 23);
		object.add(3, 2, 1);
		object.add1(3, 4);
	
	}
}

class addition {

	public void add(int a, int b)
	{
		int c= a+b;
		System.out.println(c);
		}
	public void add(int a, int b,int c)
	{
		int d= a+b+c;
		System.out.println(d);
		}
	public void add1(int c, int d)
	{
		int e= c+d;
		System.out.println(e);
		}
	
	
}
