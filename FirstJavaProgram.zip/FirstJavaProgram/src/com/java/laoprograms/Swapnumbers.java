package com.java.laoprograms;

public class Swapnumbers {

	public static void main(String[] args) {
		
		
	int x = 34;
	int y = 45;
	
	System.out.println("Before swapping x is " + x);
	System.out.println("Before swapping y is " + y);
	int temp=x;
	x=y;
	y=temp;
	
	System.out.println("After swapping x is " + x);
	System.out.println("After swapping y is " + y);

	}

}
