package com.java.laoprograms;

public class Arrayforeach {

	public static void main(String[] args) {
		// for each element for each element (i:a)
		
		int a[]= {234,23432,3333,111,222};
		
		for (int i : a) {
		
			System.out.println(i);
		}

		
		String[] base = {"test", "jag", "kruthi", "raksa", "aswanth"};

		for (String each : base) {
			
			System.out.println(" for each print chars are-   " + each);
		}
		
		int b[]= { 12,44,44,55,55};
		
		
	}

}
