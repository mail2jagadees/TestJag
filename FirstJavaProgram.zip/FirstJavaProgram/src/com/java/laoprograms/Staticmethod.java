package com.java.laoprograms;

public class Staticmethod {

	public static void main(String[] args) {
		// static method
		
		System.out.println("This is starting inside main");
		//one obj=new one();
		one.ones(); //when it is static we can directly call without creating objects
		one obj=new one();
		obj.three();
		
	}
}

class one
{
	
public static void ones()//static
{
System.out.println("This is method one");	
}
public void two()
{
System.out.println("This is method two");
}
public void three()
{
System.out.println("This is method three");	
}
			
	
}