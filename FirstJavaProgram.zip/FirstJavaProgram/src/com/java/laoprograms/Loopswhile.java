package com.java.laoprograms;

public class Loopswhile {

	public static void main(String[] args) {
		// loops while
		
		int i=1;
		while (i<=10) {
			System.out.println(i);	
			i=i+1;

		}
		
	}

}
