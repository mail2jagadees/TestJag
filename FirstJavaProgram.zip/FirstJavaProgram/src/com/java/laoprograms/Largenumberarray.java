package com.java.laoprograms;

public class Largenumberarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		int array[]= {12,33,44,55,66,77,88};
		
		for (int i = 0; i < array.length; i++) {
			
			System.out.println(array[i]);

		}
		

	}

}
