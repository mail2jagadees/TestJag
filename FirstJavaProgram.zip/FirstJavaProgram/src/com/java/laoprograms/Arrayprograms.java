package com.java.laoprograms;

public class Arrayprograms {

	public static void main(String[] args) {
		// array programs
		
		//traditional way of printing
		
	   int age[] = { 1,2,3,4,5,6,9,12};
	   String[] names = {"test", "jag", "I love"};
	   
		/**System.out.println(age[0]);
		System.out.println(age[1]);
		System.out.println(age[2]);
		System.out.println(age[3]);
		System.out.println(age[4]);**/
		
		//instead use for loop to print simply array with for loop
		
		 int b= age.length;
	    
		for (int i = 0; i < b; i++) {
			
			System.out.println("For loops arrays are " + age[i]);
			
		}
		
		for (int i = 0; i < names.length; i++) {
			
			System.out.println("For names are " +  names[i]);
		}
		
	}

}
