package com.java.laoprograms;

import java.util.Scanner;

public class FAPInterviews {

	public static void main(String[] args) {
		// factorial program for a given number
/*		
		int n=3;
		int factorial=1;
		
		for (int i = 1; i <= 3; i++) {
			
		factorial= factorial*i;
		
		*/
	
		
	//	System.out.println(factorial);
		
		//-------------------------------------------------------------
		//fibonacci series
		/*
		int n1=0;
		int n2=1;
		int sum = 0;
		System.out.println(n1);
		System.out.println(n2);

		for (int i = 2; i < 5; i++) {
			sum = n1+n2;
			n1=n2;
			n2=sum;
			System.out.println(sum);
		}
		
		*/
	//------------------------------------------------	count a words from string
	
		System.out.println("Enter the string: ");
		Scanner sc= new Scanner(System.in);
		String get= sc.nextLine();	
		int count = 1;
		
		for (int i = 0; i < args.length-1; i++) {
			
			if((get.charAt(i)==' ' )&& (get.charAt(i+1)!=' '))
			{
				count++;
			}
			
		}
		
		System.out.println(count);
		
		
}
}
