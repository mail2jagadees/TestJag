package com.java.laoprograms;

public class Variables {
	
	int a = 23; // a is declared outside method and inside class , this is instance variable
	
	static int c = 30;
	

	public static void main(String[] args) {
		// three types 1. Local 2. Instance 3. Static
		
		// Local variable can be declared with in method, outside method we cant access
		
		// Instance- all are objects, we create class. IT declared within a class not a method. To access them we need to create object
		
		// Static- Memory alloted only once and is declared using STATIC keyword. We can directly access.
	
		
		int b =22; // b is declared inside method, it is local variable
		
		Variables obj= new Variables();// a is instance variable so we need to create an object to access it
		
		System.out.println(obj.a);
		System.out.println(b);
		System.out.println(c);
		

	}

}
