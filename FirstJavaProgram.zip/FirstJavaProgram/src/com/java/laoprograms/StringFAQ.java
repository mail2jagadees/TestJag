package com.java.laoprograms;

public class StringFAQ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//number of occurance
		
		String given="rakshaaswanth";
		String find="a";
		int occurance=0;
		
		for (int i = 0; i < args.length; i++) {
			
			if (given.charAt(i)==find) {
				
				occurance=occurance+1;
				
			}
		}
		
		System.out.println(occurance);

	}

}
