package com.java.laoprograms;

public class Condtional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int age = 2;
		if (age>19) {
			System.out.println("eligible for vote");
		}
		else {
			
			System.out.println("Not eligible for vote");
		}

	} 	

}
