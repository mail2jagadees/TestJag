package com.javacollections;

import java.util.List;
import java.util.ArrayList;

public class Arraylist {

	public static void main(String[] args) {
		
		// array list is one of the class provided to implement the list
		// In list duplicate values are allowed and insertion order is maintained
		
		// create arraylist of cars and print the index value

		ArrayList<String> cars = new ArrayList<String>();
		cars.add("Honda");
		cars.add("BMW");
		cars.add("Benz");
		cars.add("Maruthi");
		cars.add("Audi");
		System.out.println("The given list is :" + cars);
		
		//use get method to print particular index
		String first=cars.get(1);
		System.out.println("Get method for first index: " + first);
		
		//to get the index of particular string given in list
		int index=cars.indexOf("Audi");
		System.out.println("The index of given car is:" + index);
		
		//To modify an element, use the set() method and refer to the index number
		cars.set(2, "Tata");
		System.out.println("Modified list are: " + cars);
		
		//To remove an element, use the remove() method and refer to the index number:
		cars.remove(2);
		System.out.println("Removed list is: " + cars);
	
		
		//To remove all the elements in the ArrayList, use the clear() method:
		//cars.clear();
		//System.out.println("Cleared list is: " + cars);
		
		
		//To find out how many elements an ArrayList have, use the size method:
		
		System.out.println(cars.size());
		
		//sort() method for sorting lists alphabetically or numerically:
		
		cars.sort(null);
		System.out.println("The sorted list is: " + cars);
	}
	
	

}
