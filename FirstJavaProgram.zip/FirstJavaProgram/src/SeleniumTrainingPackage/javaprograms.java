package SeleniumTrainingPackage;

public class javaprograms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
