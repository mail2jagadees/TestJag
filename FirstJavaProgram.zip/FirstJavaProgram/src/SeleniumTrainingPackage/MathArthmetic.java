package SeleniumTrainingPackage;

import java.util.Scanner;
  
public static void main(String[] args) {
	//To create simple calculator
	//to create object Class Name Obj Name = new Classname();
	
	MathArthmetic obj = new MathArthmetic();
	obj.Balance();
	
	
}

public class MathArthmetic {

    Integer accountbalance=3424;
    String accountname="jag";
    double interstrate=12.22;

    
public void Balance() {
System.out.printf("the account balance is "+ accountbalance);
}
}

