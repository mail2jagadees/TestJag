package SeleniumTrainingPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoTooltipTITLEIMG {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		//code to print attribute. popup1 title 1
	//	driver.get("https://www.gsmarena.com/realme-phones-118.php");
	//	String pagetitle=driver.findElement(By.xpath("//img[contains(@src,'5s')]")).getAttribute("title");
	//	System.out.println(pagetitle);
		//code to print popup type2 -calander
		driver.get("https://www.redbus.in/");
		driver.findElement(By.xpath("//span[contains(@class, 'calendar')]")).click();
		driver.findElement(By.xpath("//td[text()='26']")).click();
		
		
	}

	
}
