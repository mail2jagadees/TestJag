package SeleniumTrainingPackage;

public class Democlass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("This main method");
		FIRST o1=new FIRST();
		o1.method1();

	}
	
class FIRST {	
	
	public void method1() {
			System.out.println("This is method1");
	}

	public void method2() {
		
		System.out.println("This is method2");
	}
}
}
