package SeleniumTrainingPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//Login test case and check title of the page

public class LoginAct {

	public static void main(String[] args) throws InterruptedException {
	
		 System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.get("https://demo.actitime.com");
		 Thread.sleep(20000);
		 driver.findElement(By.id("username")).sendKeys("admin");
		 driver.findElement(By.name("pwd")).sendKeys("manager");
		 driver.findElement(By.xpath("//a[@id=\"loginButton\"]")).click();
		 
		 String expectedTitle = "actiTIME - Enter Time-Track";
		 
		 String ActualTitle = driver.getTitle();
		 
		 if (ActualTitle.equals(expectedTitle)) {
			 
			System.out.println("Title is : actiTIME - Enter Time-Track ");
			System.out.println("Test is Passed");
		}
		 else {
			System.out.println("Title is not correct");
		}
		 driver.quit();
	}

}
