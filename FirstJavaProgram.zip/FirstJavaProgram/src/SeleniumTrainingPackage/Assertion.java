package SeleniumTrainingPackage;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Assertion {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.spicejet.com");
		String a= driver.getCurrentUrl();
		String b=driver.getTitle();
		System.out.println(" the title a is " + a);
		System.out.println(" the url is " + b);
		/* '''driver.switchTo().frame("destination_publishing_iframe_spicejet_0");
		String c= driver.getCurrentUrl();
		System.out.println(" the url is " + c);'''   */
		
		Assert.assertEquals("1 Adult",driver.findElement(By.id("divpaxinfo")).getText());  
		
		System.out.println(driver.findElement(By.id("divpaxinfo")).getText());  
		
		

	}

}
