package SeleniumTrainingPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Codingisfun {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		 System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.get("https://www.tutorialspoint.com/selenium/selenium_automation_practice.htm");
		 //Thread.sleep(10000);
		 driver.findElement(By.name("firstname")).click();
		 boolean firstname =driver.findElement(By.name("firstname")).isDisplayed();
		 
		 System.out.println(firstname);

		 driver.findElement(By.name("firstname")).sendKeys("Jag");
		 
		 boolean lastname =driver.findElement(By.name("lastname")).isDisplayed();
		 
		 System.out.println(lastname);

		 
		 driver.findElement(By.name("lastname")).click();

		 driver.findElement(By.name("lastname")).sendKeys("Kruthi");
		 
		 
		 
	}

}
