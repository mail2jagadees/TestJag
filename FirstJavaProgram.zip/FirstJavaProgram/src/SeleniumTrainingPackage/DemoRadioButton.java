package SeleniumTrainingPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoRadioButton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.navigate().to("https://krninformatix.com/sample.html");
		 boolean female = driver.findElement(By.id("female")).isSelected();
		 System.out.println(female);
		 driver.findElement(By.id("female")).click();
		 
		 boolean femalesel = driver.findElement(By.id("female")).isSelected();
		 System.out.println(femalesel);
		 boolean male =driver.findElement(By.id("male")).isSelected();
		 System.out.println(male);
		 driver.findElement(By.id("male")).click();
		 boolean malesel=driver.findElement(By.id("male")).isSelected();
		 System.out.println(malesel);
		 
		 boolean maleenable = driver.findElement(By.id("male")).isEnabled();
		 System.out.println(maleenable);
		 

		 boolean femaleenable = driver.findElement(By.id("female")).isEnabled();
		 System.out.println(femaleenable);
		 
		 
		 driver.close();
		 
		
		
	}

}
