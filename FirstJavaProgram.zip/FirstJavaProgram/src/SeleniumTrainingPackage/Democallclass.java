package SeleniumTrainingPackage;

public class Democallclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void Salem() {
		
		System.out.println("This is salem");
	}

}
