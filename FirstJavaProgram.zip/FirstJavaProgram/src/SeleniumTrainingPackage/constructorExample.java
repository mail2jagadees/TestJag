package SeleniumTrainingPackage;

public class constructorExample {

	String student_name;
	
	public static void main(String[] args) {
		// demo constructor- default Types of constructor:Default,No argument,Parameterized

		
		constructorExample object= new constructorExample();
		 
		System.out.println(object.student_name);
		
		
		
	}

}


