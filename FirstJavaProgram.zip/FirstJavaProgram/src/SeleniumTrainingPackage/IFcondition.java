package SeleniumTrainingPackage;

public class IFcondition {

	public static void main(String[] args) {
		
		String Actual= "this is to test url";
		String Expected= "this is to test url";
		
		
		if (Actual.equals(Expected)) {
			System.out.println("Value is true");
			}
		else {
			System.out.println("value is false");
		}
	}

}
