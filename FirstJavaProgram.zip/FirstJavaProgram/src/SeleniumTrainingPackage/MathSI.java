package SeleniumTrainingPackage;

import java.util.Scanner;

public class MathSI {

	public static void main(String[] args) {

			//to calculate simple interest
		
		//declaration
		
		double Principal;
		int Noofyears;
		float Rate;
		double SI;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the value of Principal: ");
		Principal = in.nextDouble();
		System.out.println("Enter the value of No of years: ");
		Noofyears=in.nextInt();
		System.out.println("Enter the rate of interest: ");
		Rate=in.nextFloat();
		
		SI = (Principal*Noofyears*Rate)/100;
		
		System.out.printf("The value of SI is = %.3f", SI);
		
		
		
		

	}

}
