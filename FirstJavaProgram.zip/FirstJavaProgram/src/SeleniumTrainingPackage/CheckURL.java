package SeleniumTrainingPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckURL {

	public static void main(String[] args) throws InterruptedException {
		// Check URL of the page if displayed correctly or not:
		
		 System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.get("https://demo.actitime.com");
		 
		 //Thread.sleep(10000);
		 
		 //Login 
		 
		 driver.findElement(By.id("username")).sendKeys("admin");
		 driver.findElement(By.name("pwd")).sendKeys("manager");
		 driver.findElement(By.xpath("//a[@id=\"loginButton\"]")).click();
		 
		 Thread.sleep(15000);
		 
		 String title_page= driver.getTitle();
		 System.out.println(title_page);
		
		 String EURL="https://demo.actitime.com/user/submit_tt.do";
		 String AURL=driver.getCurrentUrl();
		 if (AURL.equals(EURL)) {
			System.out.println("Test URL is correct");
		}
		 else {
			System.out.println("URL is not correct");
		}
		 driver.close();
	}

}
