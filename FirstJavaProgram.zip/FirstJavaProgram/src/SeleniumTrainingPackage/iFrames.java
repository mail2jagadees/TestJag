package SeleniumTrainingPackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.SendKeys;

public class iFrames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://krninformatix.com/frames/frames.html");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		//open url and type something , if	we run it wont work in chrome/firefox because it is inside frame

		// driver.findElement(By.name("name1")).sendKeys("test");

		//go to frame index 0,1,2 below one will work

		//driver.switchTo().frame(1);
		//driver.findElement(By.name("name1")).sendKeys("test");

		//if too many iframes go with string frame

		//driver.switchTo().frame("secondframe");
		//driver.findElement(By.name("name1")).sendKeys("test");


		//frame name string and pass it

		driver.switchTo().frame("secondframe");
		driver.findElement(By.name("name1")).sendKeys("test");


	}

}
