package SeleniumTrainingPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoURL {

	public static void main(String[] args) {
		
		 System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.get("https://krninformatix.com/sample.html");
		 String actualurl=driver.getCurrentUrl();
		 String expectedurl="https://krninformatix.com/sample.html";
		if (actualurl.equals(expectedurl)) {
			System.out.println("Pass");
		} else {
			System.out.println("Fail");
		}
		driver.close();
				 
		

	}

}
