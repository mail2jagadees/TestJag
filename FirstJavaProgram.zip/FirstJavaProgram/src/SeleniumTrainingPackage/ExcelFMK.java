package SeleniumTrainingPackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Cell;



public class ExcelFMK {

	public static void main(String[] args) throws EncryptedDocumentException, IOException {
		
		try {
			FileInputStream File1= new FileInputStream("C:\\Users\\u6037920\\Documents\\Learning\\Selenium\\Excel Framework\\Inputsheet\\data.xlsx");
			Workbook wb= WorkbookFactory.create(File1);
			Sheet s = wb.getSheet("Sheet1");
			Row r= s.getRow(1);
			Cell c=r.getCell(0);
			String value =c.getStringCellValue();
			System.out.println(value);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}
