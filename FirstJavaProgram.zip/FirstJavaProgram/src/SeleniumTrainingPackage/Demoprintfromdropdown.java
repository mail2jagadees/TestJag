package SeleniumTrainingPackage;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.seleniumhq.jetty9.util.component.LifeCycle.Listener;

public class Demoprintfromdropdown {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://krninformatix.com/sample.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS );
		
		WebElement singleselect= driver.findElement(By.id("city"));
		Select dd= new Select(singleselect);
		
		List<WebElement> alloption =dd.getOptions();
		
		
		// write the below code
		
		/*
		WebElement firstwebelement= alloption.get(0);
		String firstelement= firstwebelement.getText();
		System.out.println(firstelement);
		
		
		WebElement Secondwebelement= alloption.get(1);
		String secondelement= Secondwebelement.getText();
		System.out.println(secondelement);
		
		
		WebElement Thirdwebelement= alloption.get(2);
		String Thirdelement= Thirdwebelement.getText();
		System.out.println(Thirdelement);
		

		WebElement Fourthwebelement= alloption.get(3);
		String Fourthelement= Fourthwebelement.getText();
		System.out.println(Fourthelement);
		
		
		*/
		//to simplify use for loop instead
		
		int size=alloption.size();
	
		for (int i = 0; i < size; i++) {
			
			WebElement AllWEBelement= alloption.get(i);
			String Allelement= AllWEBelement.getText();
			System.out.println(Allelement); 
			driver.close();
	
			
		}
		
	}

}
