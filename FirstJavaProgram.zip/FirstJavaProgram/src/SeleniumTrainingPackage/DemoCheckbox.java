package SeleniumTrainingPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoCheckbox {

	public static void main(String[] args) {
		

		 System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.navigate().to("https://krninformatix.com/sample.html");
		 
		 //check status of remember me checkbox
		  boolean Enable = driver.findElement(By.id("rem")).isEnabled();
		  System.out.println(Enable);
		  boolean Enable1 = driver.findElement(By.id("rem")).isDisplayed();
		  System.out.println(Enable1);
		  boolean Enable2= driver.findElement(By.id("rem")).isSelected();
		  System.out.println(Enable2);
		  
		  driver.findElement(By.id("rem")).click();
		  boolean selected= driver.findElement(By.id("rem")).isSelected();

		  System.out.println(selected);
		  
		  driver.close();
		  
		

	}

}
