package SeleniumTrainingPackage;

public class add {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AddTwoIntegers obj= new AddTwoIntegers();
		obj.AddTwoIntegers(;)
	}
	
		
		
		public class AddTwoIntegers {

		    public static final String AddTwoIntegers = null;

			public static void main(String[] args) {
		        
		        int first = 10;
		        int second = 20;

		        System.out.println("Enter two numbers: " + first + " " + second);
		        int sum = first + second;

		        System.out.println("The sum is: " + sum);
		    }
		}

	

