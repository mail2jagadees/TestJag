package SeleniumTrainingPackage;


public class ClassesProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("This is begining");
		
	One O1= new One();
		O1.Bangalore();
		
		Two O2= new Two();
		O2.Chennai();
		
		Three O3= new Three();
		O3.Mumbai();
		
		Four O4= new Four();
		O4.Madurai();
		

		
		

	}
	
}

class One {
	
	public void Bangalore() {
	
		System.out.println("This is bangalore");
	}
	
}

class Two {
	public void Chennai() {
		System.out.println("This is chennai");
	}
}

class Three {
	public void Mumbai() {
		System.out.println("This is Mumbai");		
	}
}

class Four {
	void Madurai() {
		System.out.println("This is Madurai");		
	}
	void Trichy() {
		System.out.println("This is Trichy");
	}

	


}


