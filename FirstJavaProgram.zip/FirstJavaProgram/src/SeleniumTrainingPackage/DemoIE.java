package SeleniumTrainingPackage;

import org.openqa.selenium.ie.InternetExplorerDriver;

public class DemoIE {

	public static void main(String[] args) {
		
		
		// IE browser
		System.setProperty("webdriver.ie.driver","C:\\Users\\u6037920\\Documents\\IEDriverServer\\IEDriverserver.exe");
		
		InternetExplorerDriver driver = new InternetExplorerDriver();
		
		driver.get("https://flipkart.com");
	

	}

}
